# GreenField – Đặt sân bóng mini

Website **đặt sân** *bóng đá mini*.

| Thư mục | Nội dung |
|---|---|
| docs | Tài liệu bàn giao |
| data | Bảng tính đặt sân |
| logs | Log truy cập website |

## Cấu trúc dự án

```powershell
Get-ChildItem -Recurse -Force
```

## Công việc

- [x] Sắp xếp thư mục dự án
- [ ] Upload dự án lên GitHub

> Không upload file .env lên GitHub.
